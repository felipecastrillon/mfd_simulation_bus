package main;
import models.*;
import java.awt.*;
import org.jgrapht.graph.DefaultWeightedEdge;

public class StreetSegment extends DefaultWeightedEdge implements java.io.Serializable{
    public static double[] inflow = {1,1};
    public double[] speed_ma;
    public static double exitRate=1;
    public static int LENGTH; // in # cells
    public int[] cell, cell_new; //spacing in # cells
    private double dens, flow, speed;
    public Color SignalColor=Color.GREEN;
    public Color[] CarColor;
    public boolean access=false,yadoblo=true, open=true;
    public int kk,dir,nOutLinks;
    private Simulator sim = new Daganzo();
    public int iMB=-1, vMB=-1, n_ma=1;
    public Node va,  vb, CarDest[];
    public StreetSegment nS, nextS;
    private Network net;
    private static int speed_dt = 200;

    public StreetSegment(){
    }

    public StreetSegment(Network n, Node vaa, Node vbb, int L, int d){// (double density, double Global.deltaX, Simulator sim) {
        net = n;
        va = vaa;
        vb = vbb;
        LENGTH=L;
        dir=d;
        ini();
    }

    public void ini(){
        kk = ((dir==Global.EW)||(dir==Global.WE))?0:1;
        setSimulator (sim);
        cell  = new int[LENGTH+1];
        cell_new  = new int[LENGTH+1];
        CarColor = new Color[LENGTH];
        CarDest = new Node[LENGTH];
        speed_ma = new double[speed_dt];
        for (int i = 0; i < speed_ma.length; i++) speed_ma[i]=0*Global.OMEGA;
 // ini the road
        for (int i=0;i<LENGTH;i++) 
          if (Math.random() < 2)cell[i] = -1; 
          else{
            CarColor[i]= Global.rndColor();
            CarDest[i] = net.getNode(3, 3);
          }
        System.arraycopy( cell, 0, cell_new, 0, cell.length );//cell_new=cell
  }

    public void setSimulator (Simulator sim) {
        this.sim = sim;
        sim.init (Global.OMEGA, LENGTH, Global.deltaX);
  }

    public void insertMB() {
        int i = 0;
        if (cell[i] == -1);
        cell[i] = 0;
        iMB=(iMB==-1)? i : -1;
  }

    public double getDens() {
        return dens;
    }

    public double getFlow() {
        return flow;
    }

    public void updateSpeeds() {
        int gap=9999,j,i;
        boolean primero;
        for (i = 0;i < LENGTH;i++){
            primero=false;
            if(cell[i] > -1){
                // searching for the vehicle ahead
                gap=9999;
                for (j = i+1;j <= LENGTH;j++){
                    if(cell[j]>-1) {
                        gap = j-i-1;
                        break;
                    }
                }
                if ((gap==9999)&&(LENGTH-1-i<Global.OMEGA)){//it's the street leader AND light is green
                    primero=true;
                    if (yadoblo){
                        nS = getNextSegment(i);
                        yadoblo=false;
                        if(nS!=null){
                            j=0;
                            while ((j <= Global.OMEGA)&&(nS.cell[j]==-1))j++;
                            gap=LENGTH-1-i+j;
                        }
                    }else//no ha doblado
                        if(nS!=null){//nS from last time-step
                            j=0;
                            while ((j <= Global.OMEGA)&&(nS.cell[j]==-1))j++;
                            gap=LENGTH-1-i+j;
                        } //else gap=9999
                }
                cell[i] = sim.updateSpeed (cell[i], gap, Global.slowdown, Global.lambda);
            }
        }
  }

    public void updatePos() {
        int j,i=0;
        while (i < LENGTH){
            j=i;
            if(cell[i] > 0){
              j = i+cell[i];
              if (j<LENGTH){// exchange the positions
                    cell_new[j] = cell[i];
                    cell_new[i] = -1;
                    CarColor[j]=CarColor[i];
                    CarDest[j] =CarDest[i];
              }else{//j>LENGTH
                    if(nS!=null){
                        int k=j%LENGTH;
                        if(nS.cell[k]==-1){//ojo
                            nS.cell_new[k]=cell[i];
                            cell_new[i] = -1;
                            yadoblo=true;
                            nS.CarColor[k]=CarColor[i];
                            nS.CarDest[k] =CarDest[i];
                        }else {
//    System.out.println("dir"+dir+ "cago...si= "+cell[i]+" i.."+i+" nS.sk= "+nS.cell[k]+" k= "+k);
                        }
                    }else {//nS = null => exits
                        if(Math.random() < exitRate){
                            cell_new[i] = -1;
                            yadoblo=true;
                        }
                    }
                }
            }else if(cell[i] == 0){
                cell_new[i] = cell[i];
            }
            i=j+1;
      }
  }

    public void update_s() {
        System.arraycopy( cell_new, 0, cell, 0, cell.length );//cell=cell_new
    }

    public StreetSegment getNextSegment(int i) {
        StreetSegment nSS = null;
        if(vb!=CarDest[i]) nSS = (StreetSegment) vb.sp.getPathEdgeList(CarDest[i]).get(0);
 //       if((va.j==3)&&(vb.i==5))System.out.println("nSS= "+nSS);
        return nSS;
    }

   @Override
   public String toString(){
       return(va.name +" -> "+vb.name);
   }

    public double getSpeed() {
        double s=0;
        for (int i = 0; i < speed_ma.length; i++) s+=speed_ma[i];
        if(s==0)s=0.00000000000000001;

//        if((va.i==5)&&(va.j==4)&&(vb.i==5)&&(vb.j==5)){
//            String c="";
//            for (int i = 0; i < speed_ma.length; i++) c=c+"|"+speed_ma[i];
//            System.out.println("sma "+c);
//        }

        return s/speed_ma.length;
    }

    public void measure() {
        int vsum=0, rhoc=0;

        for(int i=0;i<LENGTH;i++) {
          if (cell[i] >-1) {
            vsum+=cell[i];
            rhoc++;
          }
        }
        speed= 20*((rhoc > 0) ? (double)(vsum)/(double)(rhoc) : Global.OMEGA);
        dens = 1000*(double)(rhoc)/(double)(LENGTH*Global.deltaX);
        flow = speed*dens;
        speed_ma[n_ma] = speed;
        n_ma=(n_ma+1)%speed_dt;
//        if((va.i==5)&&(va.j==4)&&(vb.i==5)&&(vb.j==5)||(rhoc>0)){
//            System.out.println("speed "+speed_ma[n_ma]+" na "+n_ma+"|"+va.name+"->"+vb.name);
//        }
  }

    public void boundaries(){
        if ((access)&&(cell[0]==-1))
            if (Math.random() < inflow[kk]){
                cell[0] = 0;
                CarColor[0]=Global.rndColor();
                //Node vbb = net.getNode(6, 6);
               // String str = CityApplet.txtAB.getText();
              //  if(str.length()>3)
                //    vbb=net.getNode(Integer.parseInt(str.substring(2,3)),Integer.parseInt(str.substring(3,4)));
                int i = (int)(Math.random()*net.BLOCKS+.5);
                int j = (int)(Math.random()*net.BLOCKS+.5);
                CarDest[0] = net.getNode(i,j);
            }

        int tt = (CityApplet.t + vb.offset)%vb.cycle;
        if ((tt>=vb.tIniGreen[kk])&&(tt<vb.tEndGreen[kk])){
            cell[LENGTH]=-1;
            SignalColor = Color.GREEN;
        } else {
            cell[LENGTH]=0;
            SignalColor = Color.RED;
        }
    }
}