package main;
import java.awt.*;

public class Global {
    public static final int WE=1,EW=2,NS=3,SN=4;
  // model Parameters
    public static final int OMEGA = 4;
    public static final int deltaX = 7; //m
    public static final double slowdown = 0.01;
    public static final double density  = 0.2;
    public static final double lambda   = 0.77;

    public static final  String nodeName(int i, int j) {
        return i + " - " + j;
    }

    public static Color CarColor(int v) {
        Color c=Color.black;
        switch(v){
            case 0:c=Color.black; break;
            case 1:c=Color.red; break;
            case 2:c=Color.orange; break;
            case 3:c=Color.yellow; break;
            case 4:c=Color.green; break;
        }
        return c;
    }

    public static Color rndColor() {
        Color c = new Color((int)(Math.random()*255),(int)(Math.random()*255),(int)(Math.random()*255));
        return c;
    }

    public static void drawArrow(Graphics2D g2d, int xCenter, int yCenter, int x, int y, float stroke) {
      double aDir=Math.atan2(xCenter-x,yCenter-y);
      g2d.drawLine(x,y,xCenter,yCenter);
      g2d.setStroke(new BasicStroke(1f));					// make the arrow head solid even if dash pattern has been specified
      Polygon tmpPoly=new Polygon();
      int i1=12+(int)(stroke*2);
      int i2=6+(int)stroke;							// make the arrow head the same size regardless of the length length
      tmpPoly.addPoint(x,y);							// arrow tip
      tmpPoly.addPoint(x+xCor(i1,aDir+.5),y+yCor(i1,aDir+.5));
      tmpPoly.addPoint(x+xCor(i2,aDir),y+yCor(i2,aDir));
      tmpPoly.addPoint(x+xCor(i1,aDir-.5),y+yCor(i1,aDir-.5));
      tmpPoly.addPoint(x,y);							// arrow tip
      g2d.drawPolygon(tmpPoly);
      g2d.fillPolygon(tmpPoly);						// remove this line to leave arrow head unpainted
    }
    private static int yCor(int len, double dir) {return (int)(len * Math.cos(dir));}
    private static int xCor(int len, double dir) {return (int)(len * Math.sin(dir));}

    public static String TimeToString(int ttt) {
        String tt="";
        int h, m, s;
        h = ttt/(3600);
        m = (ttt%(3600))/60;
        s = ttt-m*60-h*3600;
        return h+":"+m+":"+s;
    }
}
