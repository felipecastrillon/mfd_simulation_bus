package main;
import org.jgrapht.alg.BellmanFordShortestPath;

public class Node {
    public static int Ncycle=60, Noffset0 = 0, Noffset1 = 0, rred=5;
    public int cycle=60, offset = 0, i, j;
    public static double NgocEW=.5;
    public double rndCycle=0;
    public  int[] tIniGreen={0,0}, tEndGreen={0,0};
    public String name;
    BellmanFordShortestPath sp;

    public Node() {
    }

    public Node(int ii, int jj) {
        i = ii;
        j = jj;
        name = Global.nodeName(i, j);
        setSignalTiming();
    }

    public void setSignalTiming() {
        cycle=(int)((1+rndCycle)*Ncycle);
        offset=Noffset0*i+Noffset1*j;
        int gEW=(int)(cycle*NgocEW);
        tIniGreen[0] = 0;
        tEndGreen[0] = gEW-rred;
        tIniGreen[1] = gEW;
        tEndGreen[1] = cycle-rred;
    }


}
//GGGGGGGGGGGGrRRRRRRRRRRRRR
//RRRRRRRRRRRRRGGGGGGGGGGGGr