package main;
import org.jgrapht.graph.DirectedWeightedMultigraph;
import org.jgrapht.alg.BellmanFordShortestPath;

public class Network {
    public int BLOCKS, TurnProbOption;
    public double dens, flow, speed, Pmax=.1, GenerationRate=0,  CompletionRate=0;
    public double dens0, flow0, speed0;
    public double dens1, flow1, speed1;
    public boolean incident=false;
    private int ns0=0,ns1=0, Cost_dt = 10;

    public  DirectedWeightedMultigraph<Node, StreetSegment> graph; // The graph of the network
    BellmanFordShortestPath sp;

    public Network(int b, int L, int op) {
        BLOCKS=b;
        TurnProbOption=op;
        StreetSegment st;
        graph = new DirectedWeightedMultigraph<Node, StreetSegment>(StreetSegment.class);
        Node va=null, vb=null;
//horizontal links
        for (int i = 0; i < BLOCKS+1; i++){
            for (int j = 0; j < BLOCKS+1; j++){
                if(j==0){
                    va = new Node(i, j);
                    graph.addVertex(va);
                }else{
                    vb = new Node(i, j);
                    graph.addVertex(vb);
                    st = new StreetSegment(this, va, vb, L, Global.WE);
                    graph.addEdge(va, vb, st);
                    st = new StreetSegment(this, vb, va, L, Global.EW);
                    graph.addEdge(vb, va, st);
                    va = vb;
                }
            }
        }
//vertical links
        for (int j = 0; j < BLOCKS+1; j++){
            for (int i = 0; i < BLOCKS+1; i++){
                if(i==0){
                    va = getNode(i, j);
                }else{
                    vb = getNode(i, j);
                    st = new StreetSegment(this, va, vb, L, Global.NS);
                    graph.addEdge(va, vb, st);
                    st = new StreetSegment(this, vb, va, L, Global.SN);
                    graph.addEdge(vb, va, st);
                    va = vb;
                }
            }
        }

        calc_nst();

        for(StreetSegment s : graph.edgeSet()){
            va = graph.getEdgeSource(s);
            vb = graph.getEdgeTarget(s);
            s.nOutLinks = graph.outDegreeOf(vb);
            for(StreetSegment sT : graph.outgoingEdgesOf(vb)){
                Node vbT = graph.getEdgeTarget(sT);
                if(va.i == vb.i){//E-W link
                    if((va.j==0)&&(va.i!=BLOCKS)&&(va.i!=0)||(va.j==BLOCKS)&&(va.i!=BLOCKS)&&(va.i!=0))s.access=true;
                    if((vbT.i == va.i)&&(vbT.j!=va.j))s.nextS=sT;
                }else{//N-S link
                    if((va.i==0)&&(va.j!=BLOCKS)&&(va.j!=0)||(va.i==BLOCKS)&&(va.j!=BLOCKS)&&(va.j!=0))s.access=true;
                    if((vbT.j == va.j)&&(vbT.i!=va.i))s.nextS=sT;
                }
            }
        }
    }

    public void update(){
        if (CityApplet.t%Cost_dt==0)update_cost();
        measure();
        for(StreetSegment s : graph.edgeSet())s.boundaries();
        for(StreetSegment s : graph.edgeSet())s.updateSpeeds();
        for(StreetSegment s : graph.edgeSet())s.updatePos();
    }

    public void update_s(){
        for(StreetSegment s : graph.edgeSet())s.update_s();
//        if(GenerationRate+CompletionRate>0)GenerateAndComplete();
    }

    public void setRndCycles(double u){
        for(Node v : graph.vertexSet())
            v.rndCycle= u*Math.random();
    }

    public void setSignalTiming(){
        for(Node v : graph.vertexSet())v.setSignalTiming();
    }

    public void SetParks(int ni, int nj) {

        for(StreetSegment s : graph.edgeSet())s.open=true;

        for (int q = 0; q <ni; q++) {
            int i = 1+(int)(Math.random()*BLOCKS-2);
            int j = 1+(int)(Math.random()*BLOCKS-2);
//            graph.getEdge(Global.nodeName(i,j),Global.nodeName(i,j+1)).open=false;
//            graph.getEdge(Global.nodeName(i,j+1),Global.nodeName(i,j)).open=false;
        }
        for (int q = 0; q <nj; q++) {
            int i = 1+(int)(Math.random()*BLOCKS-2);
            int j = 1+(int)(Math.random()*BLOCKS-2);
//            graph.getEdge(Global.nodeName(i,j),Global.nodeName(i+1,j)).open=false;
//            graph.getEdge(Global.nodeName(i+1,j),Global.nodeName(i,j)).open=false;
        }
    }

    public void GenerateAndComplete() {
        for(StreetSegment st : graph.edgeSet()){
            int[] s = st.cell;
            for (int c = 0; c < s.length; c++) {
                if(s[c]==-1)
                    st.cell[c]=(Math.random()<GenerationRate)?0:s[c];
                else if(s[c]>-1)
                    st.cell[c]=(Math.random()<CompletionRate)?-1:s[c];
            }
        }
    }

    public void measure(){
        for(StreetSegment s : graph.edgeSet()){
                s.measure();
                dens0+= (s.dir==Global.WE||s.dir==Global.NS)? s.getDens():0;
                dens1+= (s.dir==Global.EW||s.dir==Global.SN)? s.getDens():0;
                flow0+= (s.dir==Global.WE||s.dir==Global.NS)? s.getFlow():0;
                flow1+= (s.dir==Global.EW||s.dir==Global.SN)? s.getFlow():0;
       }
    }

    public void calc_nst(){
        for(StreetSegment s : graph.edgeSet()){
            ns0+= (s.dir==Global.WE||s.dir==Global.NS)? 1:0;
            ns1+= (s.dir==Global.EW||s.dir==Global.SN)? 1:0;
       }  
        if(BLOCKS%2==0)ns1-=2*BLOCKS; else ns0-=2*BLOCKS;
        System.out.println("ns0 "+ns0);
        System.out.println("ns1 "+ns1);
    }

    public void resetqkv(){
        dens0=0; flow0=0; speed0=0;
        dens1=0; flow1=0; speed1=0;
    }

    public double getDens() {
        dens=(dens0+dens1);
        return dens/(ns0+ns1);
    }

    public double getFlow() {
        flow=(flow0+flow1);
        return flow/(double)(ns0+ns1);
    }

    public double getDens0() {
        return dens0/ns0;
    }

    public double getFlow0() {
        return flow0/ns0;
    }

    public double getDens1() {
        return dens1/ns1;
    }

    public double getFlow1() {
        return flow1/ns1;
    }

    public double getSpeed() {
        return speed/(double)(ns0+ns1);
    }

    public Node getNode(int i, int j) {
        Node v = null;
        for(Node n : graph.vertexSet())
            if((n.i == i)&&(n.j == j)){
                v = n;
                break;
            }
        return v;
    }

    private void update_cost() {
        for(StreetSegment s : graph.edgeSet()){
            double cost = s.LENGTH*Global.deltaX/s.getSpeed();
            graph.setEdgeWeight(s,cost*(1+Math.random()*.4));
        }
        for(Node v : graph.vertexSet()) v.sp = new BellmanFordShortestPath(graph, v);
    }

}
