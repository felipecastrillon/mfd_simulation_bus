package models;

public class Daganzo implements Simulator {
  private int[] ve;
  private int OMEGA;
  private double deltaX;
  public void init (int MAXS, int LENGTH, double dx) {
      OMEGA=MAXS;
      deltaX=dx;
    }

  public int updateSpeed (int speed, int gap, 
			  double prob_slowdown, double dummy_lambda) {    
    
    speed =  Math.min (OMEGA, gap);

    return speed;
  }

  public String getName() {
    return "Daganzo/Laval";
  }
}
